const express = require("express");
const app = express();
const path = require("path");
const router = express.Router();
const bodyParser = require("body-parser");

const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database("datad.db", (err) => {
  if (err) {
    return console.error(err.message);
  }
  console.log("Connected to the SQlite database.");
});

const PORT = 5500;

app.set("view engine", "ejs");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + "/"));

router.get("/", (req, res) => {
  res.sendFile(path.join(__dirname + "/index.html"));
});

router.post("/", (req, res) => {
  res.sendFile(path.join(__dirname + "/index.html"));

  db.run(
    `INSERT INTO requests (name,number,email,task) VALUES ('${req.body.name}','${req.body.number}','${req.body.email}','${req.body.task}');`,
    function (err) {
      if (err) {
        return console.log(err.message);
      }
      // get the last insert id
      console.log(`A row has been inserted with rowid ${this.lastID}`);
    }
  );
});

router.get("/account", (req, res) => {
  //   res.sendFile(path.join(__dirname + "/account.ejs"));

  db.all(`SELECT * FROM requests`, function (err, rows) {
    if (err) {
      return console.log(err.message);
    }

    res.render("pages/account", {
      rows: rows,
    });
  });
});

app.use("/", router);

app.listen(PORT, () => {
  console.log(`Running application on port: ${PORT}`);
});
