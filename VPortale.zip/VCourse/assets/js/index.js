const account = document.querySelector(".account");

const userData = JSON.parse(localStorage.getItem("userdata"));

if (userData) {
  account.innerHTML = userData.login;
}
