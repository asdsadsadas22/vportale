const inputLogin = document.querySelector(".login");
const inputPassword = document.querySelector(".password");

const registerButton = document.querySelector(".btn");

registerButton.addEventListener("click", () => {
  const userData = {
    login: inputLogin.value,
    password: inputPassword.value,
  };

  localStorage.setItem("userdata", JSON.stringify(userData));
  
  window.location.replace("/index.html");
});
