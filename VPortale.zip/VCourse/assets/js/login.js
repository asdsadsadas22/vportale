const inputLogin = document.querySelector(".login");
const inputPassword = document.querySelector(".password");

const loginButton = document.querySelector(".btn");

const errorText = document.querySelector(".error-text");

loginButton.addEventListener("click", () => {
  const userData = {
    login: inputLogin.value,
    password: inputPassword.value,
  };

  const dbData = { login: "admin", password: "admin123" }

  if (JSON.stringify(userData) === JSON.stringify(dbData)) {
    window.location.replace("/index.html");
    localStorage.setItem("userdata", JSON.stringify(userData));
  } else {
    errorText.style.opacity = 1;

    setTimeout(() => {
      errorText.style.opacity = 0;
    }, 3000);
  }
});
